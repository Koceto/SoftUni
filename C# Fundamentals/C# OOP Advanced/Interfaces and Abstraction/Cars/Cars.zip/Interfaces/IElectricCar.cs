﻿public interface IElectricCar : ICar
{
    int Battery { get; }

    string ToString();
}