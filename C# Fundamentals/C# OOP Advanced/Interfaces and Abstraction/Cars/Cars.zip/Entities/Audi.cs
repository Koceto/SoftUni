﻿public class Audi : Car
{
    public Audi(string model, string color) 
        : base(model, color)
    {
    }
}